#include "Mesh.h"
#include "../../Config/EngineRenderConfig.h"


CMesh::CMesh()
{
}

void CMesh::Init()
{
}

void CMesh::BuildMesh(const FMeshRenderingData* InRenderingData)
{
    

}

void CMesh::PreDraw(float DeltaTime)
{
    
}

void CMesh::Draw(float DeltaTime)
{
    
}

void CMesh::PostDraw(float DeltaTime)
{
    

}



