﻿#include "ObjectTransformation.h"

FObjectTransformation::FObjectTransformation()
    :M(EngineMath::IdentityMatrix4x4())
{
}

