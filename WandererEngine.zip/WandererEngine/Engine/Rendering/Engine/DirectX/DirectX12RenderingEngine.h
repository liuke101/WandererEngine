﻿#pragma once
#include "Core/DirectXRenderingEngine.h"

class CDirectX12RenderingEngine :public CDirectXRenderingEngine
{
public:



};