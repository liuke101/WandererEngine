#include "RenderingEngine.h"

void CRenderingEngine::SetMainWindowsHandle(HWND InNewMainWindowsHandle)
{
	MainWindowsHandle = InNewMainWindowsHandle;
}
