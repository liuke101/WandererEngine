﻿#include "Input.h"

FCaputureOnMouseDelegates MouseDownDelegates;
FCaputureOnMouseDelegates MouseUpDelegates;
FCaputureOnMouseDelegates MouseMoveDelegates;
FCaputureOnMouseWheelDelegates MouseWheelDelegates;