﻿#pragma once

enum ECameraType
{
    CameraRoaming,      // 相机漫游模式
    ObservationObject,  // 观察对象模式
};