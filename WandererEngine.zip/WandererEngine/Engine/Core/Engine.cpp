#include "Engine.h"

CEngine::CEngine()
{
    bTick = false;  // �ر�Tick
}
