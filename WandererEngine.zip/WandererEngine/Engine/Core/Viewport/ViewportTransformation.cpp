﻿#include "ViewportTransformation.h"

FViewportTransformation::FViewportTransformation()
    :VP(EngineMath::IdentityMatrix4x4())
{
}
