#pragma once

#ifndef FORCEINLINE
#define FORCEINLINE _forceinline
#endif
