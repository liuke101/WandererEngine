// Copyright (C) RenZhai.2022.All Rights Reserved.
#pragma once
#include "../../../public/simple_channel/simple_net_drive.h"

class FSimpleUDPNetDrive :public FSimpleNetDrive
{
public:
	FSimpleUDPNetDrive(ESimpleDriveType InDriveType);
};