// Copyright (C) RenZhai.2022.All Rights Reserved.
#include "simple_net_drive_udp.h"

FSimpleUDPNetDrive::FSimpleUDPNetDrive(ESimpleDriveType InDriveType)
{

}
